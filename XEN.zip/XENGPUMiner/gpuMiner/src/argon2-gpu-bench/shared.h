// shared.h

#pragma once
#include <mutex>

extern std::mutex mtx; // declare mutex
extern int difficulty; // declare difficulty